# K-Dramas app (pasos 1 a 3)

Incluye: navegación (Inicio / Buscar / Mi lista), catálogo de k-dramas
(populares, en emisión, mejor valorados), búsqueda y ficha con sinopsis,
géneros, episodios y reparto, todo en español vía TMDB.

## Cómo ponerla a correr
1. Instala Flutter: https://docs.flutter.dev/get-started/install
2. En una terminal: `flutter create kdramas_app`
3. Copia la carpeta `lib/` y el `pubspec.yaml` de este zip dentro de `kdramas_app`
   (reemplazando los existentes) y borra `test/widget_test.dart`.
4. Consigue tu API key de TMDB (gratis en https://www.themoviedb.org/settings/api).
   No la escribas en ningún archivo.
5. `flutter pub get` y luego
   `flutter run --dart-define=TMDB_API_KEY=tu_clave`

## Android (versión release)
En `android/app/src/main/AndroidManifest.xml`, antes de `<application>`, agrega:
`<uses-permission android:name="android.permission.INTERNET"/>`

## Siguientes pasos
3. (hecho) "Dónde verlo" por país
4. Mi lista guardada en el teléfono
5. Reproductor de YouTube con canales oficiales
